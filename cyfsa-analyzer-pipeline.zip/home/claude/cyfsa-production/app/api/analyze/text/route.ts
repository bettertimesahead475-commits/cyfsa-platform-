// app/api/analyze/text/route.ts
// ============================================================
// CYFSA PLATFORM — ANALYZE PASTED TEXT
// POST /api/analyze/text
// For parents who copy-paste document text directly
// ============================================================

import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { analyzeDocument } from "@/lib/analyzerEngine";

const MONTHLY_LIMITS: Record<string, number> = {
  free: 0,
  starter: 5,
  case_builder: Infinity,
  analyzer_pro: Infinity,
};

export async function POST(req: NextRequest) {
  const supabase = createRouteHandlerClient({ cookies });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  // Plan check
  const { data: profile } = await supabase
    .from("parent_profiles")
    .select("subscription_plan")
    .eq("user_id", user.id)
    .single();

  const plan = profile?.subscription_plan || "free";
  const limit = MONTHLY_LIMITS[plan] ?? 0;
  if (limit === 0) {
    return NextResponse.json({ error: "Document analysis requires Starter plan or higher.", upgrade_url: "/dashboard?section=upgrade" }, { status: 403 });
  }

  if (limit !== Infinity) {
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);
    const { count } = await supabase
      .from("analysis_results").select("*", { count: "exact", head: true })
      .eq("parent_id", user.id).gte("analyzed_at", monthStart.toISOString());
    if ((count || 0) >= limit) {
      return NextResponse.json({ error: `Monthly limit of ${limit} analyses reached. Upgrade for unlimited.`, upgrade_url: "/dashboard?section=upgrade" }, { status: 403 });
    }
  }

  const body = await req.json();
  const { text, document_category, case_id, document_title } = body;

  if (!text || text.trim().length < 100) {
    return NextResponse.json({ error: "Please paste at least 100 characters of document text." }, { status: 400 });
  }
  if (text.length > 150000) {
    return NextResponse.json({ error: "Text is too long (max ~150,000 characters). Try splitting the document into sections." }, { status: 400 });
  }

  let analysisResult;
  try {
    analysisResult = await analyzeDocument(text.trim(), document_title || "Pasted Document", document_category);
  } catch (err: any) {
    return NextResponse.json({ error: "Analysis failed. Please try again.", detail: err.message }, { status: 500 });
  }

  // Save to DB
  const { data: savedResult } = await supabase.from("analysis_results").insert({
    document_id: null,
    case_id: case_id || null,
    parent_id: user.id,
    document_type: analysisResult.document_type,
    document_summary: analysisResult.document_summary,
    overall_risk_level: analysisResult.overall_risk_level,
    overall_risk_score: analysisResult.overall_risk_score,
    flags: analysisResult.flags,
    positive_factors: analysisResult.positive_factors,
    cross_examination_questions: analysisResult.cross_examination_questions,
    motions_to_consider: analysisResult.motions_to_consider,
    documents_to_prepare: analysisResult.documents_to_prepare,
    lawyer_summary: analysisResult.lawyer_summary,
    urgency_note: analysisResult.urgency_note,
    flag_count_high: analysisResult.flag_count_high,
    flag_count_medium: analysisResult.flag_count_medium,
    flag_count_low: analysisResult.flag_count_low,
  }).select().single();

  return NextResponse.json({ success: true, analysis_id: savedResult?.id || null, ...analysisResult });
}
