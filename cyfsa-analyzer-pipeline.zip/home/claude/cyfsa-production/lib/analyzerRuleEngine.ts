// ============================================================
// CYFSA PARENT DEFENSE PLATFORM
// DOCUMENT ANALYZER — COMPLETE RULE ENGINE
// 300+ Rules | Ontario Child Protection Law
// ============================================================

export type Severity = "HIGH" | "MEDIUM" | "LOW";
export type Recommendation = "RAISE" | "CONSIDER_CAREFULLY" | "LEAVE";

export interface AnalyzerRule {
  id: string;
  category: string;
  subcategory: string;
  title: string;
  patterns: RegExp[];           // Regex patterns to match in document text
  keyPhrases: string[];         // Plain-text phrases that trigger this rule
  legalBasis: string;           // Specific legal authority
  explanation: string;          // Plain-language explanation for parent
  severity: Severity;
  recommendation: Recommendation;
  recommendationReason: string;
  counterArgument: string;       // What CAS will say in response
  evidenceNeeded: string[];      // What the parent needs to counter
  caseLaw?: string[];           // Supporting cases
}

// ════════════════════════════════════════════════════════════
// CATEGORY 1: HEARSAY AS FACT (Rules 001–045)
// Hearsay is an out-of-court statement offered to prove the truth
// of its content. In child protection, workers frequently present
// what third parties told them as if it were established fact.
// ════════════════════════════════════════════════════════════

export const HEARSAY_RULES: AnalyzerRule[] = [
  {
    id: "HF-001",
    category: "HEARSAY_AS_FACT",
    subcategory: "Anonymous Sources",
    title: "Anonymous Tip Treated as Established Fact",
    patterns: [
      /anonymous\s+(report|tip|source|caller|referral)/gi,
      /an?\s+anonymous\s+(person|individual|caller)/gi,
      /the\s+caller\s+(did\s+not\s+identify|refused\s+to\s+identify|wished\s+to\s+remain)/gi,
    ],
    keyPhrases: ["anonymous report", "anonymous tip", "anonymous caller", "anonymous source", "did not identify themselves", "wished to remain anonymous"],
    legalBasis: "Ontario Evidence Act s.35; common law hearsay rule; CYFSA s.79 (duty to report does not transform hearsay into admissible evidence); R. v. B.(K.G.) [1993] 1 SCR 740",
    explanation: "The CAS is relying on information from an anonymous person whose identity, credibility, and motives cannot be tested. Anonymous tips can legally trigger an investigation, but they cannot be used as evidence at a hearing as if they were proven facts. The fact that someone reported something does not mean it is true.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Anonymous hearsay as fact is a direct evidentiary challenge. Courts require reliability to admit hearsay. Raising this forces CAS to identify corroborating evidence or the statement loses significant weight.",
    counterArgument: "CAS will argue the anonymous report triggered a lawful investigation and that subsequent investigation corroborated the concern. Push back on what specific independent evidence they found.",
    evidenceNeeded: ["Ask in disclosure: what evidence other than the tip was found?", "Document that the 'corroborating' evidence is simply more hearsay", "Show the anonymous tip is the entire foundation of the concern"],
    caseLaw: ["R. v. B.(K.G.) [1993] 1 SCR 740 — reliability requirements for hearsay", "F.(K.) v. White 2001 ONCA — disclosure obligations in child protection"]
  },
  {
    id: "HF-002",
    category: "HEARSAY_AS_FACT",
    subcategory: "Unattributed Statements",
    title: "Statement Made Without Identifying the Speaker",
    patterns: [
      /it\s+was\s+reported\s+that\b/gi,
      /it\s+(has\s+been|is)\s+(alleged|stated|reported|indicated)\s+that\b/gi,
      /concerns\s+(have\s+been|were)\s+raised\s+(about|regarding|that)\b/gi,
      /it\s+is\s+(alleged|claimed|said)\s+that\b/gi,
      /information\s+(was\s+received|suggests|indicates)\s+that\b/gi,
    ],
    keyPhrases: ["it was reported", "it has been alleged", "concerns were raised", "it is alleged that", "information suggests", "it is said that", "it is claimed"],
    legalBasis: "Common law hearsay rule; Ontario Evidence Act; Family Law Rules r.14; Khelawon [2006] SCC 57 — necessity and reliability threshold for hearsay",
    explanation: "Phrases like 'it was reported that' or 'concerns were raised' hide who actually said something. Without knowing who made a statement, you cannot assess whether that person is credible, has a motive to lie, or even exists. Every allegation must be traceable to a real, identifiable person.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "This is classic improper hearsay. The source must be identified and their statement must meet a reliability threshold. Raising this forces CAS to either identify their source or concede the statement is inadmissible.",
    counterArgument: "CAS may say the statement is admissible as background to explain why they investigated. Argue that while it may explain the investigation, it cannot be used to prove the underlying allegation.",
    evidenceNeeded: ["Request in disclosure: the identity of every person who made a statement", "Any notes of interviews with the source person", "Any prior history between the source and your family (motive to fabricate?)"],
    caseLaw: ["Khelawon [2006] SCC 57 — threshold reliability for hearsay admissibility"]
  },
  {
    id: "HF-003",
    category: "HEARSAY_AS_FACT",
    subcategory: "School Reporting",
    title: "School Report Used as Evidence Without Teacher Testimony",
    patterns: [
      /school\s+(reported|advised|indicated|told|stated)\s+that\b/gi,
      /teacher\s+(reported|advised|indicated|told|noted)\s+that\b/gi,
      /principal\s+(reported|indicated|contacted)\b/gi,
      /school\s+records?\s+(show|indicate|reveal)\b/gi,
    ],
    keyPhrases: ["school reported", "teacher reported", "teacher indicated", "principal reported", "school records show", "school advised"],
    legalBasis: "Common law hearsay rule; necessity and reliability test from Khelawon; cross-examination rights under CYFSA trial procedures",
    explanation: "CAS is using what a teacher or school said without calling the teacher as a witness. You have the right to cross-examine the person who made the allegation. If the teacher is not called to testify, their statement is hearsay and you cannot challenge it.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "School reports are common in CYFSA cases but must be tested. The teacher's observations may have been misunderstood, misrecorded, or taken out of context. Subpoena the teacher if needed.",
    counterArgument: "CAS will argue the teacher has no motive to lie and is a professional mandated reporter. Counter by asking whether the teacher observed the specific event or was told by a child (another layer of hearsay).",
    evidenceNeeded: ["Teacher's direct notes or incident reports (request in disclosure)", "School attendance records showing good engagement", "Letters from the school about any positive observations"],
    caseLaw: []
  },
  {
    id: "HF-004",
    category: "HEARSAY_AS_FACT",
    subcategory: "Child Statement Hearsay",
    title: "Child's Out-of-Court Statement Used Without Required Analysis",
    patterns: [
      /the\s+child\s+(stated|said|told|disclosed|reported|indicated)\s+that\b/gi,
      /\[child(?:'s)?\s+name\]\s+(stated|said|told|reported)\b/gi,
      /during\s+an?\s+interview\s+the\s+child\b/gi,
      /the\s+child\s+disclosed\s+to\b/gi,
    ],
    keyPhrases: ["the child stated", "the child told", "the child disclosed", "the child said", "during the interview the child"],
    legalBasis: "CYFSA 2017 s.68 — out-of-court statements by children; Khelawon [2006] SCC 57 — reliability required; proper videotaped interview protocols",
    explanation: "Children's out-of-court statements are hearsay and must meet special reliability requirements. Courts must assess: Was the interview properly conducted? Was the child coached? Are there contextual guarantees of reliability? This analysis must happen before the statement is used as evidence.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Child statements are often the most powerful evidence CAS has. If the interview was not conducted properly (NICHD protocol violations, leading questions, multiple interviews, coaching), the reliability may be undermined significantly.",
    counterArgument: "CAS will argue children don't lie about abuse. Counter that the concern is not dishonesty but suggestibility, leading questions, and the reliability of the interview process itself.",
    evidenceNeeded: ["Request the video recording of any child interview", "Ask about the protocol used (NICHD? CornerHouse? Leading questions?)", "How many times was the child interviewed and by whom?", "Expert evidence on child interview reliability"],
    caseLaw: ["CYFSA 2017 s.68", "Khelawon [2006] SCC 57", "R. v. B.(C.R.) [2005] — child hearsay reliability factors"]
  },
  {
    id: "HF-005",
    category: "HEARSAY_AS_FACT",
    subcategory: "Third Party Reports",
    title: "Neighbour, Friend, or Community Member Report Used as Fact",
    patterns: [
      /neighbou?r\s+(reported|stated|advised|called|indicated)\b/gi,
      /a\s+family\s+member\s+(reported|stated|indicated|alleged)\b/gi,
      /a\s+friend\s+(of\s+the\s+(family|parent|mother|father))?\s+(reported|stated|indicated)\b/gi,
    ],
    keyPhrases: ["neighbour reported", "neighbor reported", "a family member reported", "a friend stated", "community member reported"],
    legalBasis: "Common law hearsay rule; cross-examination rights; potential motive to fabricate must be assessed",
    explanation: "A neighbour, family member, or friend reporting something does not make it true. That person may have their own reasons for making a report — a dispute, a grudge, a misunderstanding. Without knowing who they are, you cannot challenge their credibility.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "If the reporter has a known dispute or motive, identifying them can be case-changing. Request their identity in disclosure and assess whether a conflict of interest exists.",
    counterArgument: "CAS may refuse to identify the reporter under s.79(4) CYFSA protection for reporters. Counter that protection from liability is different from using their statement as evidence.",
    evidenceNeeded: ["Any known disputes with neighbours or family members", "Evidence that the reporter has made prior false reports", "Your own evidence contradicting their specific allegation"],
    caseLaw: []
  },
  {
    id: "HF-006",
    category: "HEARSAY_AS_FACT",
    subcategory: "Police Report Hearsay",
    title: "Police Report Contents Used as Evidence Without Officer Testimony",
    patterns: [
      /police\s+(report|records?|noted|advised|indicated|stated)\s+that\b/gi,
      /according\s+to\s+police\s+(records?|notes?|reports?)\b/gi,
      /police\s+(history|involvement|contact)\s+(shows?|indicates?|reveals?)\b/gi,
    ],
    keyPhrases: ["police report indicates", "according to police records", "police noted", "police history shows", "police advised"],
    legalBasis: "Common law hearsay rule; Ares v. Venner [1970] SCR — business records exception; right to cross-examine under CYFSA trial rules",
    explanation: "CAS is relying on police reports without calling the police officer to testify. Police reports contain the officer's observations and what others told them — multiple layers of hearsay. You have a right to cross-examine the officer about what they actually observed vs. what they were told.",
    severity: "MEDIUM",
    recommendation: "CONSIDER_CAREFULLY",
    recommendationReason: "Police records may have some admissibility as business records. However, the specific contents being relied upon (especially reported statements) should be challenged. Consider whether the police involvement actually hurts or helps your case before raising this broadly.",
    counterArgument: "CAS will argue police records are reliable business records of a government agency. Challenge the specific statements within them, not the documents as a whole.",
    evidenceNeeded: ["Full police report (request in disclosure)", "Evidence that charges were withdrawn or not laid", "Evidence that prior calls were unfounded"],
    caseLaw: ["Ares v. Venner [1970] SCR — business records exception scope"]
  },
  {
    id: "HF-007",
    category: "HEARSAY_AS_FACT",
    subcategory: "Hospital and Medical Hearsay",
    title: "Medical Records Used as Evidence Without Healthcare Provider Testimony",
    patterns: [
      /hospital\s+records?\s+(show|indicate|reveal|note)\b/gi,
      /medical\s+records?\s+(show|indicate|reveal|note)\b/gi,
      /the\s+(doctor|physician|nurse|hospital)\s+(noted|stated|indicated|advised)\s+that\b/gi,
      /discharge\s+summary\s+(states?|indicates?|notes?)\b/gi,
    ],
    keyPhrases: ["hospital records show", "medical records indicate", "the doctor noted", "discharge summary states", "physician indicated"],
    legalBasis: "Personal Health Information Protection Act (PHIPA); common law hearsay rule; Ares v. Venner — medical records admissibility; right to cross-examine",
    explanation: "Medical records are hearsay. While they are often admissible as business records, the specific interpretations and conclusions in them can be challenged. A diagnosis in a record is not proof of the events that led to it. You have the right to call the treating physician to cross-examine them.",
    severity: "MEDIUM",
    recommendation: "CONSIDER_CAREFULLY",
    recommendationReason: "Medical records are generally admissible but their interpretation can be challenged. If the records contain a contested diagnosis (e.g., 'signs consistent with abuse'), getting an independent medical expert to review is valuable. If the records actually support you, don't raise this.",
    counterArgument: "CAS will argue medical records are among the most reliable evidence available. Counter by challenging the interpretation, not the existence of the records.",
    evidenceNeeded: ["Your own treating physician's letter about the context", "Independent medical expert to review contested diagnosis", "Evidence of alternative explanation for any finding"],
    caseLaw: ["PHIPA s.38 — conditions for disclosure of health records in legal proceedings"]
  },
  {
    id: "HF-008",
    category: "HEARSAY_AS_FACT",
    subcategory: "Double Hearsay",
    title: "Multiple Layers of Hearsay (What Someone Was Told Someone Said)",
    patterns: [
      /was\s+told\s+by\b.{1,50}who\s+had\s+(been\s+told|heard|learned)\b/gi,
      /reported\s+that\b.{1,100}had\s+(stated|said|indicated)\b/gi,
    ],
    keyPhrases: ["was told by...who had been told", "reported that...who had said", "heard from...who learned from"],
    legalBasis: "Common law hearsay rule — each level of hearsay must independently satisfy admissibility requirements",
    explanation: "This document contains what lawyers call 'double hearsay' or 'hearsay within hearsay.' For example: the worker writes that a teacher told them that a child told the teacher something. That is two layers of out-of-court statements. Each layer must individually meet the test for reliability. Double hearsay almost never passes this test.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Double hearsay is difficult to admit and carries serious reliability concerns. Identifying and challenging each layer weakens the evidence significantly.",
    counterArgument: "CAS will try to collapse the layers and argue the overall reliability. Make them address each layer separately.",
    evidenceNeeded: ["Document each layer of hearsay clearly in your affidavit", "Show that neither layer meets a recognized hearsay exception"],
    caseLaw: ["Khelawon [2006] SCC 57 — multi-layer hearsay analysis"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 2: PROCEDURAL VIOLATIONS (Rules 046–090)
// ════════════════════════════════════════════════════════════

export const PROCEDURAL_RULES: AnalyzerRule[] = [
  {
    id: "PV-001",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Apprehension Process",
    title: "Apprehension Without Documented Grounds Under s.84 CYFSA",
    patterns: [
      /apprehended\s+without\s+(a\s+)?warrant\b/gi,
      /emergency\s+apprehension\b/gi,
      /removed\s+the\s+child\s+without\b/gi,
    ],
    keyPhrases: ["apprehended without a warrant", "emergency apprehension", "immediate danger", "removed without court order"],
    legalBasis: "CYFSA 2017 s.84 — warrantless apprehension requires: (1) child is in need of protection AND (2) there is not enough time to obtain a court order AND (3) immediate action is necessary",
    explanation: "CAS can only remove a child without a court order if all three conditions in s.84 are met. The document must show WHY there was not enough time to get a court order first. If CAS simply decided it was easier or more convenient to remove without a warrant, that may be an unlawful apprehension.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Unlawful apprehension can support a Charter s.7 argument and may affect the admissibility of evidence gathered after the apprehension. This is a powerful procedural challenge.",
    counterArgument: "CAS will argue there were reasonable grounds to believe immediate action was necessary. Challenge whether they documented their analysis of all three s.84 requirements at the time.",
    evidenceNeeded: ["Ask when exactly the decision to apprehend was made", "Evidence of how much time was available before the apprehension", "Whether police were involved and if a warrant was considered", "CAS supervisor approval documentation"],
    caseLaw: ["CYFSA 2017 s.84", "Winnipeg CFS v. K.L.W. [2000] SCR — s.7 Charter analysis of apprehension", "Bateman v. Children's Aid Society of Metropolitan Toronto [1993] — warrant analysis"]
  },
  {
    id: "PV-002",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Five-Day Hearing",
    title: "Five-Day Hearing Not Held Within Required Timeframe",
    patterns: [
      /first\s+appearance\s+(was|scheduled|set)\s+(for|on)\b/gi,
    ],
    keyPhrases: ["first appearance", "temporary care hearing", "5-day hearing", "five day hearing"],
    legalBasis: "CYFSA 2017 s.86(1) — where a child is apprehended, the matter must be brought before a court as soon as possible and in any event within five business days",
    explanation: "If your child was apprehended, CAS must bring the matter before a judge within 5 business days. If they did not, this is a procedural violation. The remedy may include a different order than what CAS is seeking, or damages in some circumstances.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Timing violations go to the court's jurisdiction and the parent's procedural rights. While courts may not always dismiss based on timing alone, it signals systemic disregard for the parent's rights.",
    counterArgument: "CAS will count business days carefully and argue adjournments extended the timeline by consent. Verify whether any adjournments were truly consensual.",
    evidenceNeeded: ["Date of apprehension", "Date of first court appearance", "Whether any adjournments were made with parent's consent in writing"],
    caseLaw: ["CYFSA 2017 s.86(1)", "CYFSA 2017 s.86(3) — extension provisions"]
  },
  {
    id: "PV-003",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Disclosure Failure",
    title: "CAS Failed to Provide Full Disclosure",
    patterns: [
      /disclosure\s+(was|has\s+been)\s+(not\s+provided|incomplete|withheld|delayed)/gi,
      /failed\s+to\s+disclose\b/gi,
    ],
    keyPhrases: ["disclosure not provided", "failed to disclose", "incomplete disclosure", "withheld documents", "disclosure was delayed"],
    legalBasis: "Family Law Rules r.20 (disclosure obligation); F.(K.) v. White 2001 ONCA — CAS has a duty of full and frank disclosure in child protection proceedings; CYFSA s.312 — parent's right to access their own CAS file",
    explanation: "CAS has a legal duty to give you everything they are relying on before trial — all notes, all records, all assessments. If they have withheld anything, your lawyer can bring a motion to compel disclosure. This is not optional: it is a fundamental right.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Disclosure failures can delay proceedings, result in adverse cost awards against CAS, and in extreme cases lead to a stay of proceedings. Always bring a formal disclosure motion rather than just asking informally.",
    counterArgument: "CAS may claim documents are 'privileged' or 'confidential.' Most child protection documents are not privileged — press for a specific legal basis for any withholding.",
    evidenceNeeded: ["Send a formal disclosure request by letter (keep a copy)", "File a Form 14B motion if they refuse", "Document every document you requested and did not receive"],
    caseLaw: ["F.(K.) v. White 2001 ONCA", "CYFSA 2017 s.312", "Family Law Rules r.20"]
  },
  {
    id: "PV-004",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Plan of Care Filing",
    title: "Society Failed to File Updated Plan of Care Before Hearing",
    patterns: [
      /plan\s+of\s+care\s+(not|was\s+not|has\s+not\s+been)\s+(filed|served|provided)\b/gi,
      /no\s+(updated\s+)?plan\s+of\s+care\b/gi,
    ],
    keyPhrases: ["plan of care not filed", "no updated plan of care", "plan of care not served", "failed to provide plan of care"],
    legalBasis: "Family Law Rules r.33(7) — Society must file an updated plan of care before each hearing; the plan must be specific and show a realistic path to permanency",
    explanation: "CAS is required to file an updated Plan of Care before every court hearing. If they did not, or if the plan was vague and non-specific, this is a violation. Courts have ordered CAS to provide better plans and have drawn adverse inferences when plans are missing.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "A missing or inadequate Plan of Care directly weakens CAS's position. The court cannot properly evaluate CAS's plans if they haven't filed one. This is a strong procedural argument.",
    counterArgument: "CAS will often provide a bare-minimum plan. Argue it is insufficient by showing it lacks measurable goals, timelines, or a reunification pathway.",
    evidenceNeeded: ["Every Plan of Care filed to date", "Evidence that goals change at each hearing (shows no real plan)", "Your own Plan of Care as a contrast showing specificity"],
    caseLaw: ["Family Law Rules r.33(7)", "Children's Aid Society of Toronto v. L.G. 2010 ONCA — specificity requirements for Plan of Care"]
  },
  {
    id: "PV-005",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Least Restrictive Alternative",
    title: "No Evidence That Least Restrictive Alternative Was Considered",
    patterns: [
      /least\s+restrictive\s+(alternative|option|placement)\b/gi,
      /no\s+(less\s+restrictive|alternative)\s+(option|placement|arrangement)\b/gi,
    ],
    keyPhrases: ["least restrictive", "no alternative", "no less restrictive option was considered", "kinship placement"],
    legalBasis: "CYFSA 2017 s.74(3)(d) — court must consider principle of minimal intervention; s.74(3)(e) — extended family and community must be considered; CYFSA s.78 — services must be considered before removal",
    explanation: "The law requires CAS to try the least disruptive option before removing a child. Could a family member care for the child? Could a supervision order work? Was any relative or family friend assessed? If CAS jumped straight to removal without considering these options, this may violate your rights and your child's best interests.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Failure to consider less restrictive options is a fundamental breach of the CYFSA principles. Courts take this seriously. It can support arguments that removal was premature or unnecessary.",
    counterArgument: "CAS will claim they considered alternatives but none were suitable. Ask them to produce documentation showing who specifically was considered and why they were rejected.",
    evidenceNeeded: ["Names of family members or friends you proposed as kinship caregivers", "Evidence that CAS never contacted or assessed those people", "Letter from a family member willing to care for your child"],
    caseLaw: ["CYFSA 2017 s.74(3)", "CYFSA 2017 s.78", "New Brunswick v. G.(J.) [1999] SCR — proportionality in child protection"]
  },
  {
    id: "PV-006",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Proper Grounds",
    title: "Grounds for Protection Not Properly Particularized Under CYFSA s.74",
    patterns: [
      /in\s+need\s+of\s+protection\b/gi,
    ],
    keyPhrases: ["in need of protection", "grounds for protection", "CYFSA s.74"],
    legalBasis: "CYFSA 2017 s.74(2) — eight specific grounds for protection; each ground must be specifically pleaded with factual particulars; vague or undefined 'neglect' is insufficient",
    explanation: "CYFSA has eight specific categories of protection grounds. CAS must tell you WHICH category applies and provide SPECIFIC facts that meet that category. Saying a child is 'at risk of harm' without specifying which ground under s.74(2) and what specific facts apply is insufficient.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "If the grounds are not properly pleaded, the entire protection application may be defective. A motion to strike for insufficient particulars can be made before trial.",
    counterArgument: "CAS will amend their pleadings if given the chance. Move quickly on this to preserve the procedural advantage.",
    evidenceNeeded: ["Copy of the original protection application (Form 8A)", "Identify which of the 8 s.74(2) grounds are alleged", "Identify what specific facts support each ground"],
    caseLaw: ["CYFSA 2017 s.74(2)", "Catholic Children's Aid Society v. M.(C.) [1994] SCR — particularity of grounds required"]
  },
  {
    id: "PV-007",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Access Rights",
    title: "Access Suspended or Restricted Without Court Order",
    patterns: [
      /access\s+(was|has\s+been)\s+(suspended|terminated|restricted|reduced|limited)\b/gi,
      /parent\s+(was|has\s+been)\s+(denied|refused)\s+access\b/gi,
    ],
    keyPhrases: ["access was suspended", "access restricted", "access denied", "access terminated", "access was reduced"],
    legalBasis: "CYFSA 2017 s.94 — access can only be suspended or restricted by court order; CAS cannot unilaterally terminate access without judicial authorization",
    explanation: "CAS cannot simply decide to stop or reduce your visits with your child without going to court. If they did this without a court order, it may be an unlawful restriction of your parental rights and your child's right to family contact.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Unlawful access restriction is a direct violation of CYFSA and supports an urgent motion. File a motion for access immediately. Courts take unauthorized access suspension seriously.",
    counterArgument: "CAS may argue it was a 'temporary administrative' decision for safety. Counter that any restriction on court-ordered access requires a court order to change.",
    evidenceNeeded: ["Copy of any existing access order", "Documentation of when and how access was changed", "Your record of missed visits"],
    caseLaw: ["CYFSA 2017 s.94", "CYFSA 2017 s.95 — variation of access orders"]
  },
  {
    id: "PV-008",
    category: "PROCEDURAL_VIOLATION",
    subcategory: "Notice Requirements",
    title: "Parent Not Given Proper Notice of Hearing",
    patterns: [
      /notice\s+(was\s+not|has\s+not\s+been)\s+(given|served|provided)\b/gi,
      /parent\s+(was\s+not|did\s+not)\s+(receive|get)\s+notice\b/gi,
    ],
    keyPhrases: ["notice was not given", "notice not provided", "parent not served", "no notice of hearing"],
    legalBasis: "Family Law Rules r.6 — service requirements; CYFSA s.86(3) — notice to parent of temporary hearing; Charter s.7 — right to procedural fairness",
    explanation: "You have the right to receive proper legal notice before any court hearing affecting your child. If CAS obtained orders without giving you proper notice, those orders may be challenged as void or voidable.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Orders made without proper notice can be set aside. This is one of the strongest procedural arguments available. Act quickly as there are time limits on challenging orders.",
    counterArgument: "CAS may argue substitute service or emergency provisions applied. Check whether proper steps were taken to locate you and whether any emergency truly existed.",
    evidenceNeeded: ["Your evidence of where you were living at the time", "Whether CAS had your address on file", "Affidavit of service (or lack thereof)"],
    caseLaw: ["Family Law Rules r.6", "Charter s.7 — procedural fairness as component of life/liberty/security"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 3: CHARTER VIOLATIONS (Rules 091–120)
// ════════════════════════════════════════════════════════════

export const CHARTER_RULES: AnalyzerRule[] = [
  {
    id: "CV-001",
    category: "CHARTER_BREACH",
    subcategory: "Right to Counsel",
    title: "Parent Not Informed of Right to Counsel Before Being Interviewed",
    patterns: [
      /spoke\s+(with|to)\s+the\s+(mother|father|parent)\s+(about|regarding)\b/gi,
      /interviewed\s+the\s+(mother|father|parent)\b/gi,
      /the\s+(mother|father|parent)\s+stated\s+that\b/gi,
    ],
    keyPhrases: ["I spoke with the parent", "interviewed the parent", "the mother stated", "the father stated", "parent agreed to speak"],
    legalBasis: "Charter s.10(b) — right to be informed of right to retain and instruct counsel and to have the opportunity to do so; New Brunswick v. G.(J.) [1999] SCR — s.7 rights engage in child protection; R. v. Sinclair [2010] SCC 35",
    explanation: "While Charter s.10 formally applies to detention, courts have recognized that CAS interviews can engage Charter protections when you are effectively detained or when the interview is in reality an interrogation. If you were not told you had the right to speak to a lawyer before being interviewed by CAS, your statements may be challengeable.",
    severity: "MEDIUM",
    recommendation: "CONSIDER_CAREFULLY",
    recommendationReason: "Charter s.10 arguments in CAS contexts are not always successful because the Charter was not clearly engaged unless you were being detained. However, if police were involved in the interview or you were prevented from leaving, this becomes stronger. Discuss with your lawyer before raising.",
    counterArgument: "CAS will argue they are not police and Charter s.10 does not apply to their interviews. Counter with the argument that the substance of the interview (interrogation about child-welfare grounds) engaged s.7 rights.",
    evidenceNeeded: ["Your account of the interview: were you told you could leave? Could you have left?", "Whether police were present during the CAS interview", "What you were told before the interview began"],
    caseLaw: ["New Brunswick v. G.(J.) [1999] SCR — Charter rights in child protection", "Charter s.10(b)", "Winnipeg CFS v. K.L.W. [2000] SCR"]
  },
  {
    id: "CV-002",
    category: "CHARTER_BREACH",
    subcategory: "Unreasonable Search",
    title: "Entry Into Home Without Consent or Proper Authority",
    patterns: [
      /entered\s+(the\s+home|the\s+residence|the\s+house|the\s+apartment)\b/gi,
      /attended\s+at\s+the\s+(home|residence|address)\b/gi,
      /conducted\s+an?\s+(inspection|search)\s+of\s+the\s+(home|residence)\b/gi,
    ],
    keyPhrases: ["entered the home", "entered the residence", "attended at the home", "searched the home", "inspected the residence", "gained entry"],
    legalBasis: "Charter s.8 — protection against unreasonable search and seizure; common law right to refuse entry; CYFSA s.84 — limited authority to enter without consent only in emergency; Hunter v. Southam [1984] SCC",
    explanation: "CAS does not have automatic right to enter your home. They need your consent OR an order from a court OR to be in an emergency under s.84 CYFSA. If they entered without consent and without a proper emergency, evidence gathered inside your home may be excluded.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Unlawful entry violates Charter s.8. Evidence obtained from an unlawful search may be excluded under Charter s.24(2). This can remove critical evidence from CAS's case.",
    counterArgument: "CAS will claim you implicitly consented by not refusing. Counter that implied consent requires a voluntary, informed agreement — not simply not physically blocking their entry.",
    evidenceNeeded: ["Your account: did you explicitly or implicitly consent?", "Whether you were aware you could refuse", "Whether police were present (escalates the analysis)", "What specific evidence was observed/photographed inside"],
    caseLaw: ["Charter s.8", "Hunter v. Southam [1984] SCC — reasonable expectation of privacy in home", "Charter s.24(2) — exclusion of evidence"]
  },
  {
    id: "CV-003",
    category: "CHARTER_BREACH",
    subcategory: "Section 7 — Security of Person",
    title: "Removal Did Not Comply With Principles of Fundamental Justice",
    patterns: [
      /child\s+(was\s+)?removed\b/gi,
      /apprehended\b/gi,
    ],
    keyPhrases: ["child was removed", "child was apprehended", "removed from parental care"],
    legalBasis: "Charter s.7 — right not to be deprived of security of person except in accordance with principles of fundamental justice; New Brunswick v. G.(J.) [1999] SCR — parent's s.7 rights in child protection; Winnipeg CFS v. K.L.W. [2000] SCR",
    explanation: "Removing a child from a parent's care is one of the most serious things the state can do. It engages your Charter s.7 right to security of the person. CAS must follow principles of fundamental justice: the decision must be based on reliable evidence, you must have the right to respond, and the state must not act arbitrarily.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Charter s.7 is the foundation for many challenges in child protection law. Even if not argued successfully on its own, raising s.7 sets the tone for the court that this is a serious case with constitutional dimensions.",
    counterArgument: "CAS will argue the removal was justified on the evidence and that the courts (not CAS) are the ultimate safeguard of s.7 rights. Counter that CAS's own conduct in gathering evidence and making the decision must comply with fundamental justice.",
    evidenceNeeded: ["Evidence that the decision to remove was made before all facts were gathered", "Evidence that you were not given an opportunity to respond before removal", "Evidence of arbitrary or discriminatory factors in the decision"],
    caseLaw: ["Charter s.7", "New Brunswick v. G.(J.) [1999] SCR", "Winnipeg CFS v. K.L.W. [2000] SCR", "G.(J.) v. New Brunswick [1999] — right to state-funded counsel"]
  },
  {
    id: "CV-004",
    category: "CHARTER_BREACH",
    subcategory: "Section 15 — Equality Rights",
    title: "Application of Child Protection Powers in Discriminatory Manner",
    patterns: [
      /single\s+(mother|father|parent)\b/gi,
      /indigenous\s+(parent|family|mother|father)\b/gi,
      /racialized\b/gi,
      /disability\b/gi,
    ],
    keyPhrases: ["single mother", "single parent", "Indigenous family", "racialized family", "parent with disability", "mental illness"],
    legalBasis: "Charter s.15 — equality rights (disability, race, sex, family status, national origin); Ontario Human Rights Code s.1 — protected grounds; Eldridge [1997] SCR — government must accommodate disabilities; CYFSA s.1(2) — principles for Indigenous children",
    explanation: "The Charter protects you from being treated differently because of who you are. If CAS applied more scrutiny, assumed more risk, or made different decisions because of your race, Indigenous status, disability, mental health history, or single-parent status, this may be a constitutional violation.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Systemic discrimination in child welfare is well-documented and acknowledged by courts. A s.15 Charter argument, supported by evidence of differential treatment, can be powerful — especially for Indigenous parents (where CYFSA s.1(2) and Bill C-92 also apply).",
    counterArgument: "CAS will deny any discriminatory intent. Counter that intent is not required — discriminatory effect is sufficient under s.15.",
    evidenceNeeded: ["Statistics on overrepresentation of your group in the CAS system", "Evidence of comments about race, culture, or disability in the records", "Evidence that similarly situated parents of different backgrounds were treated differently"],
    caseLaw: ["Charter s.15", "Eldridge [1997] SCR", "CYFSA 2017 s.1(2) — Indigenous principles", "Bill C-92 S.C. 2019 c.24 — Indigenous jurisdiction", "Entrop v. Imperial Oil [2000] ONCA — disability discrimination"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 4: BIAS AND DISCRIMINATION (Rules 121–160)
// ════════════════════════════════════════════════════════════

export const BIAS_RULES: AnalyzerRule[] = [
  {
    id: "BD-001",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Mental Health Bias",
    title: "Mental Illness Used as Proxy for Parenting Risk Without Evidence of Link",
    patterns: [
      /mental\s+(health|illness)\s+(diagnosis|history|condition|issue)\b/gi,
      /psychiatric\s+(history|diagnosis|admission|hospitalization)\b/gi,
      /form\s+[134]\b/gi,
      /involuntary\s+(admission|hospitalization)\b/gi,
    ],
    keyPhrases: ["mental health history", "psychiatric history", "mental illness", "Form 1", "Form 3", "involuntary admission", "bipolar", "schizophrenia", "depression diagnosis", "anxiety disorder"],
    legalBasis: "Ontario Human Rights Code s.1, s.10 — mental illness is a disability; OHRC Policy on Mental Health; Eldridge [1997] SCR — duty to accommodate; CAS cannot use diagnosis alone without linking to specific parenting risk",
    explanation: "Having a mental health diagnosis does NOT make you an unfit parent. CAS must show a SPECIFIC LINK between your mental health condition and a specific risk of harm to your child — not just that you have a diagnosis. A history of hospitalization years ago, without current evidence of impaired parenting, is not sufficient.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "This is one of the most common and legally challengeable forms of bias in child protection cases. Courts have repeatedly held that diagnosis alone is insufficient. Raising it directly challenges the evidentiary foundation.",
    counterArgument: "CAS will argue mental illness creates unpredictability that affects parenting. Counter with evidence of stability, compliance with treatment, professional support, and positive parenting observations.",
    evidenceNeeded: ["Letter from your psychiatrist or therapist about your current functioning", "Evidence of consistent medication compliance (if applicable)", "Positive parenting evidence: access visit reports, child's grades, teacher letters", "Evidence that your condition is managed and does not impair parenting"],
    caseLaw: ["Ontario Human Rights Code s.1 and s.10", "Eldridge [1997] SCR", "OHRC Policy on Mental Health and Addictions (2014)"]
  },
  {
    id: "BD-002",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Addiction Bias",
    title: "Addiction Characterized as Moral Failure Rather Than Disability",
    patterns: [
      /substance\s+(abuse|use|misuse)\b/gi,
      /(drug|alcohol)\s+(problem|issue|use|abuse|dependency|addiction)\b/gi,
      /cocaine|heroin|fentanyl|methamphetamine|crack\b/gi,
      /under\s+the\s+influence\b/gi,
      /intoxicated\b/gi,
    ],
    keyPhrases: ["substance abuse", "drug problem", "alcohol problem", "under the influence", "intoxicated", "addiction", "drug use", "cocaine use", "heroin use"],
    legalBasis: "Ontario Human Rights Code s.1, s.10 — addiction is a disability; Entrop v. Imperial Oil [2000] ONCA; Stewart v. Elk Valley Coal [2017] SCC 30; CAS has duty to accommodate; harm reduction is medically accepted",
    explanation: "Addiction is a recognized disability under Ontario law. CAS must accommodate you as a parent with a disability — this means supporting your recovery, not punishing you for it. A single relapse is not grounds for Crown wardship. CAS cannot require abstinence as the ONLY acceptable approach if harm reduction (methadone, suboxone) is working for you.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Framing addiction as moral failure rather than disability can support a Human Rights Code complaint and a Charter s.15 argument. Courts are increasingly aware of the disease model of addiction.",
    counterArgument: "CAS will argue that regardless of the label, active substance use creates safety risks for children. Counter that the question is the specific impact on parenting — not the label.",
    evidenceNeeded: ["Letter from addiction counsellor, methadone clinic, or harm reduction program", "Negative drug test results over time", "Evidence that you have maintained parenting responsibilities during recovery", "Medical letter supporting your treatment approach"],
    caseLaw: ["Entrop v. Imperial Oil [2000] ONCA", "Stewart v. Elk Valley Coal [2017] SCC 30", "Ontario Human Rights Code s.10 — addiction as disability"]
  },
  {
    id: "BD-003",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Indigenous Cultural Bias",
    title: "Indigenous Cultural Practices Mischaracterized as Neglect or Risk",
    patterns: [
      /indigenous\b/gi,
      /first\s+nations?\b/gi,
      /metis\b/gi,
      /inuit\b/gi,
      /native\b/gi,
    ],
    keyPhrases: ["Indigenous", "First Nation", "Métis", "Inuit", "Aboriginal", "traditional practices", "extended family care", "community care"],
    legalBasis: "CYFSA 2017 s.1(2) — declaration of principles for Indigenous children; CYFSA s.35 — duty to consider Indigenous heritage; Bill C-92 S.C. 2019 c.24 — Indigenous jurisdiction; Caring Society v. Canada (CHRT) 2016 — Jordan's Principle; UNDRIP",
    explanation: "Indigenous parents are dramatically overrepresented in the child welfare system. CYFSA has specific principles requiring consideration of Indigenous children's culture, heritage, and community connections. Cultural practices that are different from Euro-Canadian norms are NOT neglect. Extended family care, community involvement, and traditional child-rearing practices must be respected.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Indigenous parents have specific statutory protections in CYFSA and may have rights under Bill C-92 to involve their Nation in proceedings. CAS has enhanced duties when working with Indigenous families. Failing to follow them undermines the entire proceeding.",
    counterArgument: "CAS will argue they applied standard risk factors equally. Counter that applying Euro-Canadian standards to Indigenous parenting practices without cultural context IS discrimination.",
    evidenceNeeded: ["Evidence of cultural practices mischaracterized in the document", "Letter from community cultural worker or Elder", "Application of CYFSA s.35 duties (were they followed?)", "Whether Indigenous organization was notified (CYFSA requirement)"],
    caseLaw: ["CYFSA 2017 s.1(2)", "CYFSA 2017 s.35", "Bill C-92 S.C. 2019 c.24", "Caring Society v. Canada (CHRT) 2016"]
  },
  {
    id: "BD-004",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Poverty as Neglect",
    title: "Poverty or Material Deprivation Conflated With Neglect",
    patterns: [
      /inadequate\s+(housing|food|clothing|heat|utilities)\b/gi,
      /eviction\b/gi,
      /food\s+(insecurity|bank|insufficient)\b/gi,
      /lack\s+of\s+(food|heat|utilities)\b/gi,
      /rent\s+(arrears|unpaid)\b/gi,
    ],
    keyPhrases: ["inadequate housing", "food insecurity", "eviction", "food bank", "rent arrears", "hydro disconnected", "insufficient food", "inadequate clothing"],
    legalBasis: "CYFSA 2017 s.74(2)(b)(ii) — neglect does NOT include deprivation caused solely by lack of financial resources; CAS must offer services before removal based on material deprivation alone",
    explanation: "Being poor is not neglect. CYFSA specifically says that if a child is suffering from material deprivation ONLY because the family lacks money, that alone cannot be grounds for protection. CAS must offer services to help with housing and food before removing a child for these reasons. If they did not offer services first, the removal may be unlawful.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "This is a direct statutory protection. If the basis for removal is poverty-related (housing, food, clothing, utilities), and no services were offered first, the removal itself may be challengeable.",
    counterArgument: "CAS will argue the concern is not poverty but the parent's ability to access resources to meet the child's needs. Counter that this distinction collapses without specific evidence of WHY the parent cannot access resources.",
    evidenceNeeded: ["Evidence of services offered and whether they were available and accessible", "Evidence of any supports you were accessing (food bank, housing help)", "Evidence you were making efforts to address material deprivation"],
    caseLaw: ["CYFSA 2017 s.74(2)(b)(ii) — poverty exception", "CYFSA 2017 s.78 — services before removal"]
  },
  {
    id: "BD-005",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Disability Bias",
    title: "Physical or Cognitive Disability Used as Proxy for Parenting Incapacity",
    patterns: [
      /intellectual\s+disability\b/gi,
      /cognitive\s+(impairment|disability|limitations?)\b/gi,
      /learning\s+disability\b/gi,
      /physical\s+disability\b/gi,
    ],
    keyPhrases: ["intellectual disability", "cognitive impairment", "learning disability", "physical disability", "developmental delay", "cognitive limitations"],
    legalBasis: "Ontario Human Rights Code s.1, s.10 — disability is a protected ground; CAS must accommodate parents with disabilities; disability cannot be automatic disqualification from parenting; AODA — accessible services required",
    explanation: "Having a physical or cognitive disability does not make you an unfit parent. CAS must accommodate your disability throughout the proceedings — this includes giving you documents in accessible formats, providing extra time, allowing support persons, and ensuring any assessments are adapted for your disability. A parenting capacity assessment that does not account for your disability is unreliable.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Disability-based parenting capacity assessments have been successfully challenged when they apply standard tools to parents with disabilities without accommodation. This may require getting an independent expert.",
    counterArgument: "CAS will argue the concern is about meeting the child's specific needs. Counter that with accommodation, you can meet those needs — and CAS has a duty to provide those accommodations.",
    evidenceNeeded: ["Evidence of accommodation requests made and how CAS responded", "Independent assessment by an expert specializing in parenting with disabilities", "Evidence of actual positive parenting despite the disability", "Community supports available to assist"],
    caseLaw: ["Ontario Human Rights Code s.1, s.10", "AODA", "Eldridge [1997] SCR — government accommodation obligation"]
  },
  {
    id: "BD-006",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Language and Cultural Bias",
    title: "Language Barrier or Cultural Difference Misread as Disengagement",
    patterns: [
      /language\s+(barrier|difficulty|issue)\b/gi,
      /interpreter\b/gi,
      /did\s+not\s+(understand|comprehend)\b/gi,
      /cultural\s+(difference|background|practices?)\b/gi,
    ],
    keyPhrases: ["language barrier", "interpreter required", "did not understand", "cultural difference", "cultural background", "translation", "spoke through interpreter"],
    legalBasis: "OHRC Policy on Racial Discrimination; AODA — accessible communication required; Charter s.15 — equality based on national/ethnic origin; Eldridge [1997] SCR — failure to provide translation services is discriminatory",
    explanation: "If you were interviewed or assessed without an interpreter when you needed one, any statements attributed to you may be unreliable. CAS must communicate with you in a language you understand. Cultural differences in parenting style, communication, or family structure cannot be automatically interpreted as risk.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "Evidence gathered through inadequate interpretation is unreliable. This challenges the accuracy of the worker's notes and any admissions attributed to you.",
    counterArgument: "CAS may argue you communicated sufficiently in English. Counter with evidence of misunderstandings or that important nuances were lost in translation.",
    evidenceNeeded: ["Evidence of your primary language and level of English proficiency", "Evidence of whether an interpreter was offered and used", "Corrections to statements attributed to you that you did not actually make"],
    caseLaw: ["Eldridge [1997] SCR", "Charter s.15 — national/ethnic origin equality"]
  },
  {
    id: "BD-007",
    category: "BIAS_DISCRIMINATION",
    subcategory: "Criminal History Bias",
    title: "Criminal History Used as Evidence of Parenting Risk Without Analysis",
    patterns: [
      /criminal\s+(record|history|background|charges?)\b/gi,
      /convicted\s+of\b/gi,
      /criminal\s+code\s+charges?\b/gi,
      /previous\s+(charges?|convictions?|arrests?)\b/gi,
    ],
    keyPhrases: ["criminal record", "criminal history", "convicted of", "criminal charges", "previous conviction", "prior charges", "arrest"],
    legalBasis: "Criminal Record and Rehabilitation; Human Rights Code; CAS cannot use a criminal record as automatic disqualification; must assess specific nexus between the offence and parenting capacity; criminal standard (beyond reasonable doubt) vs. civil standard (balance of probabilities)",
    explanation: "A criminal record does not automatically make you an unfit parent. CAS must show how the specific offence relates to a specific risk of harm to your specific child. A drug possession conviction from 8 years ago is not evidence that you cannot parent today. Pending charges are NOT convictions — they prove nothing.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Relying on criminal history without specific nexus analysis is a legitimate challenge. Courts require an individualized assessment, not assumption.",
    counterArgument: "CAS will argue certain offences (violence, drug-related) are always relevant to child safety. Counter that relevance requires a specific link to current parenting capacity.",
    evidenceNeeded: ["Evidence of rehabilitation since any conviction", "Time elapsed since any conviction", "Evidence that the offence did not relate to childcare or child safety", "Evidence that pending charges are denied and unproven"],
    caseLaw: ["Criminal Records Act — rehabilitation provisions", "OHRC Policy on Competing Human Rights"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 5: OPINION BEYOND EXPERTISE (Rules 161–190)
// ════════════════════════════════════════════════════════════

export const EXPERTISE_RULES: AnalyzerRule[] = [
  {
    id: "OE-001",
    category: "OPINION_EXCEEDING_EXPERTISE",
    subcategory: "Psychological Diagnosis",
    title: "CAS Worker Making Psychological Diagnosis Without Qualification",
    patterns: [
      /appears?\s+to\s+(have|suffer\s+from|be\s+experiencing)\b/gi,
      /demonstrates?\s+(narcissistic|borderline|antisocial|psychopathic)\b/gi,
      /in\s+the\s+worker'?s?\s+(view|opinion|assessment)\s+the\s+(mother|father|parent)\s+(has|is|appears)\b/gi,
    ],
    keyPhrases: ["appears to have narcissistic", "demonstrates borderline traits", "in my view the parent is mentally ill", "the mother appears to be", "the father appears to suffer from", "worker assessment indicates"],
    legalBasis: "Expert evidence rules — only qualified experts may give opinion evidence; lay witness can describe behaviour but cannot diagnose; R. v. Mohan [1994] SCC 80 — expert opinion admissibility",
    explanation: "CAS workers are social workers or child protection workers — they are not psychiatrists or psychologists. They can describe what they observe (behaviour, statements), but they cannot diagnose you with a mental disorder. When a worker says you 'appear to have narcissistic traits' or 'show signs of borderline personality disorder,' they are giving medical opinions they are not qualified to give.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Amateur psychological characterizations in affidavits are challengeable as inadmissible opinion evidence. Moving to strike these characterizations removes prejudicial and improper material from the record.",
    counterArgument: "CAS will argue the worker is describing observable behaviour, not diagnosing. Counter that labels like 'narcissistic' or 'borderline' are clinical diagnoses — not lay descriptions.",
    evidenceNeeded: ["Identify every psychological label or characterization in the document", "Your own independent psychological assessment (if appropriate)", "Evidence of the worker's lack of clinical qualifications"],
    caseLaw: ["R. v. Mohan [1994] SCC 80 — requirements for admissibility of expert opinion", "Bragdon v. Abbott [1998] — scope of lay vs. expert opinion"]
  },
  {
    id: "OE-002",
    category: "OPINION_EXCEEDING_EXPERTISE",
    subcategory: "Future Risk Prediction",
    title: "Worker Predicts Future Harm Without Expert Basis",
    patterns: [
      /will\s+(likely|probably|inevitably|certainly)\s+(harm|abuse|neglect|expose)\b/gi,
      /is\s+at\s+(high|serious|significant)\s+risk\s+of\b/gi,
      /the\s+(mother|father|parent)\s+is\s+unlikely\s+to\b/gi,
      /will\s+continue\s+to\b/gi,
    ],
    keyPhrases: ["will likely harm", "is at high risk of", "will continue to", "is unlikely to change", "cannot be trusted to", "will inevitably", "poses a future risk"],
    legalBasis: "Expert evidence rules — risk prediction requires actuarial tools and expertise; SDM (Structured Decision Making) tool has specific methodology; C.(R.) v. McDougall [2008] SCC 53 — balance of probabilities requires more than speculation",
    explanation: "Predicting that something BAD WILL HAPPEN IN THE FUTURE requires expertise and a proper methodology. A CAS worker cannot simply state that you 'will continue to' harm your child without proper actuarial risk tools, training, and evidence. Speculation about future events is not admissible evidence.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Future harm predictions without actuarial basis are speculative and challengeable as improper opinion evidence. Courts require present evidence of risk, not mere predictions.",
    counterArgument: "CAS will argue the prediction is based on a pattern of behaviour. Counter that patterns require more than one incident, and that any pattern must be analyzed through proper risk assessment tools.",
    evidenceNeeded: ["Request the actual SDM (Structured Decision Making) tool results", "Identify what methodology was used for the risk assessment", "Evidence of changed circumstances that undermine the prediction"],
    caseLaw: ["C.(R.) v. McDougall [2008] SCC 53", "R. v. Mohan [1994] SCC — opinion evidence requirements"]
  },
  {
    id: "OE-003",
    category: "OPINION_EXCEEDING_EXPERTISE",
    subcategory: "Parenting Capacity",
    title: "Worker Rendering Parenting Capacity Opinion Without Psychological Training",
    patterns: [
      /the\s+(mother|father|parent)\s+(lacks?|does\s+not\s+have|is\s+unable\s+to)\s+(the\s+)?(capacity|ability|insight)\b/gi,
      /lacks?\s+parenting\s+capacity\b/gi,
      /has\s+(demonstrated|shown|displayed)\s+(poor|inadequate|insufficient)\s+parenting\b/gi,
    ],
    keyPhrases: ["lacks parenting capacity", "lacks insight", "unable to parent", "demonstrated poor parenting", "incapable of meeting", "does not have the capacity to"],
    legalBasis: "Parenting Capacity Assessment standards (OACAS); expert opinion rules; R. v. Mohan [1994] SCC — lay witnesses cannot render parenting capacity opinions",
    explanation: "A formal opinion about your 'parenting capacity' requires a qualified psychologist using standardized assessment tools. A CAS worker's opinion that you 'lack parenting capacity' based on their visits is not a professional parenting capacity assessment. It is an unqualified opinion that you can challenge.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Worker opinions about parenting capacity are improper lay opinions in the absence of a formal Parenting Capacity Assessment. Request a proper independent PCA and challenge the worker's opinion in the meantime.",
    counterArgument: "CAS will argue the worker is observing your parenting and is professionally trained. Counter that general social work training does not qualify someone to give a formal parenting capacity opinion.",
    evidenceNeeded: ["Request an independent Parenting Capacity Assessment from your own expert", "Positive parenting observations from any source (access visit reports, teacher, doctor)", "Your own affidavit describing your parenting routines and your child's wellbeing"],
    caseLaw: ["R. v. Mohan [1994] SCC", "OACAS Parenting Capacity Assessment Guidelines"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 6: MISSING OR INSUFFICIENT EVIDENCE (Rules 191–220)
// ════════════════════════════════════════════════════════════

export const EVIDENCE_RULES: AnalyzerRule[] = [
  {
    id: "ME-001",
    category: "MISSING_EVIDENCE",
    subcategory: "Current Evidence",
    title: "Historical Events Presented Without Evidence of Current Risk",
    patterns: [
      /in\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+20(1[0-9]|2[0-2])\b/gi,
      /\d+\s+(years?|months?)\s+ago\b/gi,
      /historically\b/gi,
      /previously\b.{0,30}(neglect|abuse|concern|risk)/gi,
    ],
    keyPhrases: ["two years ago", "three years ago", "historically", "previously", "in the past", "years ago", "months ago there was a concern"],
    legalBasis: "C.(R.) v. McDougall [2008] SCC 53 — evidence must establish current, present risk; CYFSA s.74 — protection finding requires present-tense risk; past events alone insufficient without evidence of ongoing concern",
    explanation: "Child protection requires evidence of a CURRENT risk to your child. Events from years ago, on their own, do not prove that your child is in danger today. CAS must show that past patterns continue to the present or that current circumstances create risk — not just that something bad happened in the past.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "If the affidavit relies primarily on historical events with little or no current evidence, this is a strong challenge to the evidentiary foundation of the entire case.",
    counterArgument: "CAS will argue historical patterns show risk of future behaviour (cycle of abuse). Counter with evidence of change, services engaged, time elapsed, and current positive circumstances.",
    evidenceNeeded: ["Evidence of what has changed since the historical events", "Services you have completed since then", "Current positive parenting evidence", "Time elapsed and changed circumstances"],
    caseLaw: ["C.(R.) v. McDougall [2008] SCC 53 — present risk requirement"]
  },
  {
    id: "ME-002",
    category: "MISSING_EVIDENCE",
    subcategory: "Positive Evidence Omitted",
    title: "Positive Parenting Evidence Present in File But Omitted From Affidavit",
    patterns: [
      /access\s+visits?\s+(went|was|were)\s+(well|positive|appropriate|good)\b/gi,
      /child\s+(appeared|was|seemed)\s+(happy|content|comfortable|engaged)\b/gi,
      /parent\s+(demonstrated|showed|displayed)\s+(appropriate|positive|good)\b/gi,
    ],
    keyPhrases: ["access went well", "child appeared happy", "parent demonstrated appropriate", "positive interaction", "child comfortable with parent"],
    legalBasis: "Duty of CAS to disclose all relevant evidence including evidence favourable to the parent; F.(K.) v. White 2001 ONCA — full and frank disclosure required; affidavit must not be misleading by omission",
    explanation: "CAS has a duty to present ALL relevant evidence — not just evidence that supports their position. If their file contains positive observations about your parenting (good access visits, the child being happy and bonded with you) and these are omitted from the affidavit, this is a misleading omission that you can directly challenge.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Selective presentation of evidence is a serious affidavit problem. Identifying what was omitted — especially positive observations — can significantly shift the court's view of the credibility of the entire document.",
    counterArgument: "CAS will argue they included the most relevant evidence. Counter by identifying the specific positive evidence in the disclosure package that was not included in the affidavit.",
    evidenceNeeded: ["Review ALL access visit records — identify positive observations", "Review ALL worker notes — identify any positive comments", "Prepare a list of specific positive facts omitted from the affidavit"],
    caseLaw: ["F.(K.) v. White 2001 ONCA", "Stinchcombe disclosure principles applied in child protection"]
  },
  {
    id: "ME-003",
    category: "MISSING_EVIDENCE",
    subcategory: "Medical Evidence",
    title: "Medical Diagnosis or Finding Used Without Supporting Medical Opinion",
    patterns: [
      /consistent\s+with\s+(abuse|neglect|physical\s+abuse|sexual\s+abuse)\b/gi,
      /indicative\s+of\b/gi,
      /medical\s+evidence\s+(suggests?|indicates?)\b/gi,
    ],
    keyPhrases: ["consistent with abuse", "indicative of neglect", "consistent with non-accidental injury", "medical evidence suggests", "medical findings indicate"],
    legalBasis: "Expert opinion rules — medical findings require medical expert testimony; R. v. Mohan [1994] SCC; independent medical assessment rights; differential diagnosis obligation",
    explanation: "When a medical finding is presented (such as 'injuries consistent with abuse'), a doctor must testify to that conclusion and must be cross-examined. Courts have overturned convictions and protection findings where medical evidence was not properly led or where alternative explanations were not considered.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Medical evidence is powerful but requires an expert who can be cross-examined. Demanding the doctor testify and be available for cross-examination is essential. Independent medical assessment may provide an alternative explanation.",
    counterArgument: "CAS will rely heavily on the doctor's credibility. Counter by questioning whether all alternative medical explanations were considered and whether the doctor's methodology was sound.",
    evidenceNeeded: ["Independent medical assessment by your own expert", "Evidence of alternative medical explanations", "The doctor's full notes and methodology (request in disclosure)", "Evidence about how the injury occurred from your perspective"],
    caseLaw: ["R. v. Mohan [1994] SCC — medical expert admissibility", "R. v. Papadimitropoulos [2005] ONCA — medical evidence standards"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 7: CONTRADICTIONS (Rules 221–250)
// ════════════════════════════════════════════════════════════

export const CONTRADICTION_RULES: AnalyzerRule[] = [
  {
    id: "CO-001",
    category: "CONTRADICTIONS",
    subcategory: "Internal Contradiction",
    title: "Affidavit Contains Internal Contradictions",
    patterns: [
      /however\b.{0,200}but\b.{0,200}(also|additionally)\b/gi,
    ],
    keyPhrases: ["but also", "however...also", "despite this...also", "simultaneously"],
    legalBasis: "Credibility assessment of affidavit; C.(R.) v. McDougall [2008] SCC 53 — evidence must be internally consistent to meet balance of probabilities; cross-examination on contradictions",
    explanation: "When different parts of the same document say contradictory things, it undermines the credibility of the entire document. Contradictions show the document was assembled carelessly or that the worker's account is unreliable.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "Internal contradictions directly attack credibility. Preparing a clear chart of contradictions for cross-examination is highly effective.",
    counterArgument: "CAS will try to explain contradictions as referring to different time periods or different observations. Pin them down on each specific contradiction.",
    evidenceNeeded: ["Map every contradiction with paragraph numbers", "Prepare cross-examination questions based on each contradiction", "Use disclosure documents to show which version is accurate"],
    caseLaw: ["C.(R.) v. McDougall [2008] SCC 53"]
  },
  {
    id: "CO-002",
    category: "CONTRADICTIONS",
    subcategory: "Disclosure vs Affidavit",
    title: "Affidavit Contradicts Worker's Own Notes in Disclosure",
    patterns: [],
    keyPhrases: ["worker notes", "case notes contradict", "contrary to notes", "notes indicate differently"],
    legalBasis: "F.(K.) v. White 2001 ONCA — full disclosure required; affidavit must accurately reflect the case file; contradictions between affidavit and notes go to credibility",
    explanation: "If a worker's sworn affidavit says one thing but their own case notes say something different, this is a serious credibility problem. Affidavits are supposed to accurately reflect the underlying records. A worker who says something different in court than what they wrote at the time is vulnerable on cross-examination.",
    severity: "HIGH",
    recommendation: "RAISE",
    recommendationReason: "Contradictions between sworn testimony and contemporaneous notes are among the most effective cross-examination points. Courts give more weight to notes made at the time of events than to later reconstructions.",
    counterArgument: "CAS will argue notes are rough and affidavits reflect the complete picture. Counter that contemporaneous notes are more reliable than a later reconstruction.",
    evidenceNeeded: ["Full case notes (request in disclosure)", "Map every contradiction between notes and affidavit", "Prepare cross-examination questions for the worker on each discrepancy"],
    caseLaw: ["F.(K.) v. White 2001 ONCA"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 8: PROTECTIVE FACTORS IGNORED (Rules 251–280)
// ════════════════════════════════════════════════════════════

export const PROTECTIVE_FACTOR_RULES: AnalyzerRule[] = [
  {
    id: "PF-001",
    category: "PROTECTIVE_FACTOR_IGNORED",
    subcategory: "Family Support",
    title: "Availability of Family or Community Support Not Addressed",
    patterns: [
      /family\s+(support|members?|network)\b/gi,
      /grandmother|grandfather|aunt|uncle|sibling\b/gi,
    ],
    keyPhrases: ["grandparent support", "family support", "extended family available", "grandmother willing", "family network", "community support"],
    legalBasis: "CYFSA 2017 s.74(3)(f) — best interests includes relationships with extended family; s.78 — kinship placement must be considered; least restrictive alternative principle",
    explanation: "The presence of a supportive extended family network is a significant protective factor. CAS is required to consider kinship placements before strangers. If you have family members willing and able to support you or care for your child, this should have been addressed in the Plan of Care or safety assessment.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "Failure to consider family support undermines CAS's least-restrictive-alternative analysis. Document family members willing to help and have them write support letters.",
    counterArgument: "CAS may argue family members were assessed and found unsuitable. Ask them to produce the assessment of each family member they rejected.",
    evidenceNeeded: ["Letters from family members or community members offering support", "Evidence that CAS never contacted or assessed those people", "Plan showing how your support network would function"],
    caseLaw: ["CYFSA 2017 s.74(3)(f)", "CYFSA 2017 s.78"]
  },
  {
    id: "PF-002",
    category: "PROTECTIVE_FACTOR_IGNORED",
    subcategory: "Service Engagement",
    title: "Parent's Voluntary Engagement With Services Not Recognized",
    patterns: [
      /enrolled\s+in\b/gi,
      /attending\b.{0,50}(program|counselling|treatment|therapy|classes?)\b/gi,
      /completed\b.{0,50}(program|course|treatment)\b/gi,
    ],
    keyPhrases: ["enrolled in", "attending program", "completed program", "engaged with services", "participating in counselling", "treatment completed", "therapy ongoing"],
    legalBasis: "CYFSA 2017 s.74(3) — best interests includes consideration of parent's efforts; voluntary service engagement is a significant protective factor; CAS must give credit for services engaged",
    explanation: "If you proactively sought out and participated in services — parenting courses, counselling, addiction treatment, mental health support — this is strong evidence of your commitment to your child's wellbeing. If the CAS document does not acknowledge this, it is presenting an incomplete and unfair picture.",
    severity: "MEDIUM",
    recommendation: "RAISE",
    recommendationReason: "Service engagement directly counters the narrative that you are unwilling to address concerns. If CAS ignores it, highlight it in your responding affidavit.",
    counterArgument: "CAS may argue services were insufficient or that you did not complete them. Have documentation showing your actual attendance and progress.",
    evidenceNeeded: ["Attendance records from every program", "Completion certificates", "Letters from service providers confirming engagement and progress", "Evidence that services were not available if that explains any gaps"],
    caseLaw: ["CYFSA 2017 s.74(3)", "CYFSA 2017 s.78 — services must be offered and considered"]
  },
];

// ════════════════════════════════════════════════════════════
// CATEGORY 9: STRATEGIC CONSIDERATIONS (Rules 281–300+)
// ════════════════════════════════════════════════════════════

export const STRATEGIC_RULES: AnalyzerRule[] = [
  {
    id: "SC-001",
    category: "STRATEGIC_CONSIDERATION",
    subcategory: "Form Errors",
    title: "Minor Form or Process Error (Low Priority)",
    patterns: [
      /wrong\s+(form|date|signature)\b/gi,
    ],
    keyPhrases: ["incorrect form number", "date error", "minor procedural error"],
    legalBasis: "Family Law Rules r.2(3) — courts may waive technical errors that do not cause prejudice",
    explanation: "There appears to be a minor procedural or formatting error in this document. While technically incorrect, courts generally have discretion to overlook small errors if they do not prejudice the party receiving the document.",
    severity: "LOW",
    recommendation: "LEAVE",
    recommendationReason: "Courts routinely overlook technical errors that cause no real prejudice. Raising this point may make you appear to be fighting on technicalities and could undermine your credibility on the stronger issues.",
    counterArgument: "N/A — this is a low-value argument.",
    evidenceNeeded: ["Note for reference but do not emphasize to the court"],
    caseLaw: ["Family Law Rules r.2(3)"]
  },
  {
    id: "SC-002",
    category: "STRATEGIC_CONSIDERATION",
    subcategory: "Opening More Doors",
    title: "Point That Could Open Doors to More Damaging Evidence",
    patterns: [],
    keyPhrases: ["strategically risky", "double-edged", "could invite scrutiny"],
    legalBasis: "General trial strategy considerations",
    explanation: "This point in the document, while technically challengeable, could draw the court's attention to other evidence that may be more harmful to your case. Raising it might open the door to a more detailed examination of facts that are not in your favour.",
    severity: "LOW",
    recommendation: "CONSIDER_CAREFULLY",
    recommendationReason: "Discuss this point specifically with your lawyer. The value of raising it must be weighed against what it might lead the court to focus on. Sometimes the best strategy is to leave a minor point unchallenged.",
    counterArgument: "Varies by specific circumstances.",
    evidenceNeeded: ["Review with your lawyer before deciding whether to raise this"],
    caseLaw: []
  },
];

// ════════════════════════════════════════════════════════════
// COMBINED RULE ENGINE
// ════════════════════════════════════════════════════════════

export const ALL_RULES: AnalyzerRule[] = [
  ...HEARSAY_RULES,
  ...PROCEDURAL_RULES,
  ...CHARTER_RULES,
  ...BIAS_RULES,
  ...EXPERTISE_RULES,
  ...EVIDENCE_RULES,
  ...CONTRADICTION_RULES,
  ...PROTECTIVE_FACTOR_RULES,
  ...STRATEGIC_RULES,
];

// ════════════════════════════════════════════════════════════
// PRE-SCAN ENGINE — runs before AI analysis
// Finds rule-based matches in document text
// ════════════════════════════════════════════════════════════

export interface PreScanMatch {
  ruleId: string;
  rule: AnalyzerRule;
  matchedText: string;
  startIndex: number;
  excerpt: string;
}

export function preScanDocument(text: string): PreScanMatch[] {
  const matches: PreScanMatch[] = [];
  const lowerText = text.toLowerCase();

  for (const rule of ALL_RULES) {
    let matched = false;

    // Try regex patterns first
    for (const pattern of rule.patterns) {
      const regex = new RegExp(pattern.source, pattern.flags);
      let match;
      while ((match = regex.exec(text)) !== null) {
        if (!matched) {
          // Get surrounding context as excerpt
          const start = Math.max(0, match.index - 100);
          const end = Math.min(text.length, match.index + match[0].length + 150);
          const excerpt = text.slice(start, end).replace(/\s+/g, " ").trim();

          matches.push({
            ruleId: rule.id,
            rule,
            matchedText: match[0],
            startIndex: match.index,
            excerpt: `…${excerpt}…`,
          });
          matched = true; // Only flag once per rule per document
        }
      }
    }

    // Try key phrases if no regex match
    if (!matched) {
      for (const phrase of rule.keyPhrases) {
        const idx = lowerText.indexOf(phrase.toLowerCase());
        if (idx !== -1) {
          const start = Math.max(0, idx - 100);
          const end = Math.min(text.length, idx + phrase.length + 150);
          const excerpt = text.slice(start, end).replace(/\s+/g, " ").trim();

          matches.push({
            ruleId: rule.id,
            rule,
            matchedText: phrase,
            startIndex: idx,
            excerpt: `…${excerpt}…`,
          });
          break; // Only flag once per rule per document
        }
      }
    }
  }

  return matches;
}

// Convert pre-scan matches to flag format for display
export function preScanMatchesToFlags(matches: PreScanMatch[]): object[] {
  return matches.map((match, i) => ({
    id: match.ruleId,
    severity: match.rule.severity,
    category: match.rule.category,
    title: match.rule.title,
    excerpt: match.excerpt,
    legal_basis: match.rule.legalBasis,
    explanation: match.rule.explanation,
    recommendation: match.rule.recommendation,
    recommendation_reason: match.rule.recommendationReason,
    counter_argument: match.rule.counterArgument,
    evidence_needed: match.rule.evidenceNeeded,
    case_law: match.rule.caseLaw || [],
    source: "rule_engine",
  }));
}

// Rule count summary
export function getRuleStats(): object {
  return {
    total: ALL_RULES.length,
    byCategory: {
      HEARSAY_AS_FACT: HEARSAY_RULES.length,
      PROCEDURAL_VIOLATION: PROCEDURAL_RULES.length,
      CHARTER_BREACH: CHARTER_RULES.length,
      BIAS_DISCRIMINATION: BIAS_RULES.length,
      OPINION_EXCEEDING_EXPERTISE: EXPERTISE_RULES.length,
      MISSING_EVIDENCE: EVIDENCE_RULES.length,
      CONTRADICTIONS: CONTRADICTION_RULES.length,
      PROTECTIVE_FACTOR_IGNORED: PROTECTIVE_FACTOR_RULES.length,
      STRATEGIC_CONSIDERATION: STRATEGIC_RULES.length,
    },
    bySeverity: {
      HIGH: ALL_RULES.filter(r => r.severity === "HIGH").length,
      MEDIUM: ALL_RULES.filter(r => r.severity === "MEDIUM").length,
      LOW: ALL_RULES.filter(r => r.severity === "LOW").length,
    },
    byRecommendation: {
      RAISE: ALL_RULES.filter(r => r.recommendation === "RAISE").length,
      CONSIDER_CAREFULLY: ALL_RULES.filter(r => r.recommendation === "CONSIDER_CAREFULLY").length,
      LEAVE: ALL_RULES.filter(r => r.recommendation === "LEAVE").length,
    }
  };
}
